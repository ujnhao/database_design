CREATE VIEW STAFF --员工信息视图
AS
SELECT YID,Yname,YSEX,Yage,YZhiCheng
FROM Y
WHERE YStatus = '0'
go

