--客户增加订单库存减少
CREATE TRIGGER Dele_KNum
  ON GT
  AFTER INSERT
  AS
  UPDATE K
  SET K.KNum = K.KNum - ins.GTQY
  from KT, T, inserted as ins
  WHERE KT.TID = ins.TID AND KT.KID = K.KID
go

