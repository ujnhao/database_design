--客户增加订单库存减少
CREATE TRIGGER Dele_KTNum
  ON GT
  AFTER INSERT
  AS
  UPDATE KT
  SET KT.QTY = KT.QTY - ins.GTQY
  from KT, T, inserted as ins
  WHERE KT.TID = ins.TID
go

