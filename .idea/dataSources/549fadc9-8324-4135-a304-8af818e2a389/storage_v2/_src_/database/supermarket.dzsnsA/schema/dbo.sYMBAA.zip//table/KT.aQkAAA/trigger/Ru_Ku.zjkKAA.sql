--仓库更新
create trigger 入库 on KT
  for insert,update
  as
  update K
  set K.KNum = K.KNum + ins.QTY
  from inserted as ins
  where K.KID = ins.KID
go

