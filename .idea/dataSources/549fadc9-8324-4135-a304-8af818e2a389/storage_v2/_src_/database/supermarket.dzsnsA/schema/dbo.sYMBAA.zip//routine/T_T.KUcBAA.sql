--商品信息查询的存储过程:
create procedure T_T
  @T_ID BIGINT
as
select * from T where TID=@T_ID
go

