--员工信息查询的存储过程:
create procedure Y_Y
  @Y_ID BIGINT
as
select * from Y where YID=@Y_ID
go

