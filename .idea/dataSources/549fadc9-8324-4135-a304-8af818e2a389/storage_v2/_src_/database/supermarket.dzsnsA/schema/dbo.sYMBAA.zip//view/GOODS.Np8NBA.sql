CREATE VIEW GOODS --创建商品目录视图
AS
SELECT TID, TName, TSellPrice, TWeight, Tpdate, Tkdate, TNorms
FROM T
go

