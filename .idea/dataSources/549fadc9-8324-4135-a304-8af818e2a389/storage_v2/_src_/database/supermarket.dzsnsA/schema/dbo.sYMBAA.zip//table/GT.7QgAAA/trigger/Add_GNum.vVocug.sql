--增加更新会员时积分与账单自动更新
CREATE TRIGGER Add_GNum
ON GT
AFTER INSERT
AS
  UPDATE G
  SET G.GNum = G.GNum + T.TSellPrice*(ins.GTQY)
  from G, T, inserted as ins
  WHERE G.GID = ins.GID AND T.TID = ins.TID
go

