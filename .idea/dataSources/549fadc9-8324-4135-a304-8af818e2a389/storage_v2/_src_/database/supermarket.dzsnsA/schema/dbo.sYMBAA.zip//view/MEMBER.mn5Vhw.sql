CREATE view MEMBER --查询会员信息视图
AS
SELECT GID, GName, GSex, GAge, GNum, GPhone
FROM G
WHERE G.GStatus = '0'
go

