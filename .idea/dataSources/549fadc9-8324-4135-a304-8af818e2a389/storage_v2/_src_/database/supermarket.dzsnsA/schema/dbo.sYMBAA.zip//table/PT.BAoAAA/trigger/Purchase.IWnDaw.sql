--进货单自动更新产品对应的供货商
create trigger Purchase on PT
  for insert,update
  as
  update PT
  set SID=ST.SID,
      PDate=GETDATE(),
      PPrice=T.TPrice
  from ST, T
  where PT.TID = ST.TID and PT.TID = T.TID
go

