CREATE VIEW 进货单与供货商
AS
SELECT PT.PTID, PT.TID, T.Tname, T.TNorms, T.Tpdate, PT.PNum, PT.PPrice,
       S.SID, S.SName, S.SAddress, S.SFax, S.STele
FROM T, S, ST, PT
where T.TID=ST.TID and ST.SID=S.SID and T.TID=PT.TID
go

