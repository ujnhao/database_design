create view KT_INFO(KID,KNum) --各库库存总量
as
select KID=KT.KID, KNum=sum(KT.QTY)
from KT
group by KT.KID
go

