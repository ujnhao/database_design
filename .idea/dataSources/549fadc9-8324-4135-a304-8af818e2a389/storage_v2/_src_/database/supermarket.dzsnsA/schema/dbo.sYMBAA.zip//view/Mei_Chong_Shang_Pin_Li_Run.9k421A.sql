CREATE VIEW 每种商品利润(TID, LiRun)
as
select TID = GT.TID, LiRun=SUM(GT.GTQY*(T.TSellPrice-T.TPrice))
from GT,T
where GT.TID=T.TID
group by GT.TID
go

