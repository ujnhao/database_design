CREATE VIEW GOODS_SUPPLIER --商品供应商信息视图
AS
SELECT ST.SID, Sname, SAddress, Stele, SFax, T.TID, Tname, TPrice, TWeight, Tpdate, Tkdate, TNorms
FROM T, S, ST
where T.TID = ST.TID and ST.SID = S.SID
go

