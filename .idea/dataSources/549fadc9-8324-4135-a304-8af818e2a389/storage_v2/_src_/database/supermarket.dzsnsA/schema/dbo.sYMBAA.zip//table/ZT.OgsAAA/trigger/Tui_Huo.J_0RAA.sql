--退货时KT（各产品剩余数）更新
create trigger 退货 on ZT
  for insert,update
  as
  update KT
  set KT.QTY = KT.QTY - ins.ZNum
  from inserted as ins
  where ins.TID = KT.TID AND GETDATE() = ins.ZDate
go

