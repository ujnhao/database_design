--进货时KT（各产品剩余数）更新
create trigger 入库量 on PT
  for insert,update
  as
  update KT
  set KT.QTY = KT.QTY + ins.PNum
  from inserted as ins
  where ins.TID = KT.TID
go

