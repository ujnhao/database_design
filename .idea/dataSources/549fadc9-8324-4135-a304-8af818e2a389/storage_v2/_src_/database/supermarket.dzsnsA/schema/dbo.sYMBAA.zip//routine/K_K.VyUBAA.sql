--库存信息查询的存储过程:
create procedure K_K
  @K_ID BIGINT
as
select* from K where KID=@K_ID
go

