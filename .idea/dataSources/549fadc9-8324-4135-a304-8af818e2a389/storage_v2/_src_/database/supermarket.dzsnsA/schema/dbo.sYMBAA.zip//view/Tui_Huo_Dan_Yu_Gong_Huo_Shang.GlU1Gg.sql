CREATE VIEW 退货单与供货商
AS
SELECT ZT.ZTID, ZT.TID, T.Tname, T.TNorms, ZT.ZDate, ZT.ZNum, ZT.ZPrice, S.Sname, S.SID, S.SAddress, S.Stele, S.SFax
FROM T, S, ST, ZT
where T.TID = ST.TID and ST.SID = S.SID and T.TID = ZT.TID
go

