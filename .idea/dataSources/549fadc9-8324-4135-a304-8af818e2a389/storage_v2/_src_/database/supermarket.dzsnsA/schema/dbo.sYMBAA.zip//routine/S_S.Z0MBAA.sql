--供应商信息查询存储过程:
create procedure S_S
  @S_ID BIGINT
as
select * from S where SID=@S_ID
go

