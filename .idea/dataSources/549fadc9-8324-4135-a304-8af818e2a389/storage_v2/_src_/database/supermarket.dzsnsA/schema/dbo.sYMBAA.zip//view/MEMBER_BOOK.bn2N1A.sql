create view  MEMBER_BOOK       --用户订单视图
as
select GT.GID, GT.TID, T.TSellPrice, GT.GTQY, GT.GTQDate
from GT, T
WHERE GT.TID = T.TID
go

