CREATE VIEW STOREHOUSE --仓库信息视图
AS
SELECT KID, KNum, KHnum, KDnum, KPersonName, KPersonTele
FROM K
go

