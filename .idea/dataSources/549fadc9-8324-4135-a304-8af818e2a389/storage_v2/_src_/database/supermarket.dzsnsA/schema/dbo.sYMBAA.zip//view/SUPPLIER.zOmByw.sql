CREATE VIEW SUPPLIER --供应商信息视图
AS
SELECT SID, SName, SAddress, Stele, Sfax
FROM S
go

