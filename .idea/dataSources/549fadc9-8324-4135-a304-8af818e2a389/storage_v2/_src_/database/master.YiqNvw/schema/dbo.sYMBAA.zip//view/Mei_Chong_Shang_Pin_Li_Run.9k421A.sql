CREATE VIEW 每种商品利润(TID,lirun)
as
select top(100)percent TID=D.TID,
                       lirun=SUM(Dnums*(D.TPrice-T.TPrice))
from D,T
where D.TPrice=T.TPrice
group by D.TID
go

