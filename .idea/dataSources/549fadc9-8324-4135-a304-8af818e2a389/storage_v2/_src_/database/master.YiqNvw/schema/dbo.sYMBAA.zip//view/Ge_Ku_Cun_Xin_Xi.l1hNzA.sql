create view 各库存信息(KNO,KNUM) --各库库存总量
as
select top(100)percent KNO=KT.KNO,
                       KNUM=sum(KT.QTY)
from KT
group by KT.KNO
go

