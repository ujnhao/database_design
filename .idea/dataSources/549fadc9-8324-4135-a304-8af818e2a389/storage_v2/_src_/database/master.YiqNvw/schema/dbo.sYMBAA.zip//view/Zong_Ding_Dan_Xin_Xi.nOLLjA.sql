create view 总订单信息 --创建订单视图
as
select SumP.Dnum,D.TID,Tname,Dnums,D.TPrice,SumP.PPrice,Ddate
from D,T,SumP
where D.TID=T.TID and SumP.Dnum=D.Dnum
go

