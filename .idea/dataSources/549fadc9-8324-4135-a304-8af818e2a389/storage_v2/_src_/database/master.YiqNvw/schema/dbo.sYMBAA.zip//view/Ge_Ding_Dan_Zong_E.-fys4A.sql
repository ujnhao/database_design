create view 各订单总额(Dnum,PPrice) --订单总价视图
as
select top(100)percent Dnum=D.Dnum,
                       PPrice=SUM(Dnums*TPrice)
from D
group by D.Dnum
go

