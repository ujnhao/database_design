CREATE VIEW 员工信息 --员工信息视图
AS
SELECT YID,Yname,YSEX,Yage,Yzhichen
FROM Y
go

