CREATE view 会员信息 --查询会员信息视图
AS
SELECT GName,GSex,GNums,GNum
FROM G
go

