CREATE VIEW 每单利润(Dnum,lirun)
as
select top(100)percent Dnum=D.Dnum,
                       lirun=SUM(Dnums*(D.TPrice-T.TPrice))
from D,T
where D.TPrice=T.TPrice
group by D.Dnum
go

