CREATE VIEW 进货单与供货商
AS
SELECT ZNO,Z.TID,T.Tname,Znums,ZPrice,TNorms,Zdate,Tpdate,Tkdate,Sname,ST.SCodename,SAddress,Stele,SFax
FROM T,S,ST,Z
where T.TID=ST.TID and ST.SCodename=S.SCodename and T.TID=Z.TID
go

