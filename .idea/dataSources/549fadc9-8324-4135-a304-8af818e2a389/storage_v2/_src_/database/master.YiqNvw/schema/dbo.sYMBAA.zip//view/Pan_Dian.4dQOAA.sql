create view 盘点
as
select D.Ddate, D.TID, T.Tname, D.DNums, D.TPrice, everyday.PPrice
from D, T, everyday
where D.TID=T.TID and D.Ddate = everyday.Ddate
go

