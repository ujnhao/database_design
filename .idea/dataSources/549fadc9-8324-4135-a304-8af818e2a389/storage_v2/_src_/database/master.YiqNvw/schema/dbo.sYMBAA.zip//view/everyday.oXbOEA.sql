create view everyday(Ddate,PPrice)
as
select top(100)percent Ddate=D.Ddate,
                       SUMPrice=SUM(Dnums*TPrice)
from D
group by D.Ddate
go

