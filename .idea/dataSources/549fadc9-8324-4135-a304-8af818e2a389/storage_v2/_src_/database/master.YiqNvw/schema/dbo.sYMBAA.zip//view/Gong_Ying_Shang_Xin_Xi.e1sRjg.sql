CREATE VIEW 供应商信息 --供应商信息视图
AS
SELECT SCodename ,SName,SAddress ,Stele,Sfax
FROM S
go

