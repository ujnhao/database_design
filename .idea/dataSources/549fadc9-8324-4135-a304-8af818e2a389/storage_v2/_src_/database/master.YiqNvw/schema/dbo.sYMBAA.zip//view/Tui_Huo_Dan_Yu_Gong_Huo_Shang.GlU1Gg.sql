CREATE VIEW 退货单与供货商
AS
SELECT PNO,P.TID,T.Tname,Pnums,PPrice,TNorms,Pdate,Sname,ST.SCodename,SAddress,Stele,SFax
FROM T,S,ST,P
where T.TID=ST.TID and ST.SCodename=S.SCodename and T.TID=P.TID
go

