CREATE VIEW 仓库信息 --仓库信息视图
AS
SELECT KNO,KNum,KHnum,KDnum,kperson
FROM K
go

