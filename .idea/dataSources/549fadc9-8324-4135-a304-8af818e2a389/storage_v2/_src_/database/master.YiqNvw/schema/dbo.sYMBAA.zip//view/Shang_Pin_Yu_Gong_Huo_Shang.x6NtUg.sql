CREATE VIEW 商品与供货商
AS
SELECT T.TID,Tname,TPrice,TWeight,Tpdate,Tkdate,TNorms,Sname,ST.SCodename,SAddress,Stele,SFax
FROM T,S,ST
where T.TID=ST.TID and ST.SCodename=S.SCodename
go

