CREATE VIEW 商品
AS
SELECT TID,Tname,TPrice,TWeight,Tpdate,Tkdate,TNorms
FROM T
go

